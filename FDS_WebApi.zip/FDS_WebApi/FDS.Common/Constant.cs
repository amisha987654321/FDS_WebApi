﻿namespace FDS.Common
{
    public static class Constant
    {
        public static string CompanyName = "Food Delivery System";

    }
}