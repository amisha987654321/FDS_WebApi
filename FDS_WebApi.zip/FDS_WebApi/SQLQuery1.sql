﻿select * from Customer
select * from Address




